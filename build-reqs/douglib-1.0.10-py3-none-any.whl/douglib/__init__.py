# -*- coding: utf-8 -*-
"""
douglib
=======

A collection of functions, classes, utilities, and other items that I've
created over the years.

"""

### Constants ###############################################################
__version__ = "1.0.10"
__project_url__ = "https://github.com/dougthor42/DougLib"
__project_name__ = "douglib"
__description__ = "Random collection of functions and utilities."
__long_descr__ = __doc__
