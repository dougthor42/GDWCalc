# -*- coding: utf-8 -*-
"""
wafer_map.py

Part of douglib. Used for plotting wafer map images specifically.

Created on Mon Aug 26 11:02:21 2013
@author: dthor
"""
from __future__ import print_function
import math
import matplotlib as mpl
import matplotlib.pyplot as pyplot
import numpy as np
from douglib.core import (rescale,
                          rcd_to_2d_array,
                          xyd_to_2d_array,
                          convert_rcd_xyd,
                          )

# Library Constants
# Defined by SEMI M1-0302
FLAT_LENGTHS = {50: 15.88, 75: 22.22, 100: 32.5, 125: 42.5, 150: 57.5}


def draw_die(rcd, plot_range, x_size=1, y_size=1):
    """ Draws a die, coloring it to fit data into plot_min to plot_max. """
    row, column, data = rcd
    plot_min, plot_max = plot_range
    # Rescale the data so that it maps to the color scale
    plot_value = rescale(data, (plot_min, plot_max))

    x_pos = column * x_size
    y_pos = row * y_size
    die = mpl.patches.Rectangle((x_pos, y_pos), x_size, y_size,
                                ec=(0, 0, 0),
                                fc=(plot_value, 0, 0), lw=1)

    return die


def plot_wafer_map(rcd, **kwargs):
                   #wafer=(150, 5, 4.5),
                   #die_xy=(2.43, 3.3),
                   #center_rc=(24, 31.5),
                   #plot_range=(10, 20)),
                   #wafer_outline=True,
                   #exclusion_outline=True,
                   #color_dict={0: (0, 0, 0),
                   #            1: (0, 0, 0),
                   #            2: (0, 0, 0)}
    """
    Plots a wafer map with outline and edge exclusion, with die color defined
    by the die data value.

    Req'd Inputs:
    rcd: list of tuples of (row_coord, col_coord, value)

    Optional Inputs (must be named):
    wafer: tuple of wafer info: (diameter, edge_exclusion, flat_exclusion)
    die_xy: tuple of (die_x, die_y) sizes
    center_rc: tuple of (center_row, center_col)
    plot_range: tuple of (min, max) plot values
    color_dict: dictionary of {value: color} that overrides default plot colors
    """

    DEFAULT_KWARGS = {'wafer': (150, 5, 4.5),
                      'die_xy': (2.43, 3.3),
                      'center_rc': (24, 31.5),
                      'plot_range': (0, 1),
                      'draw_wfr': True,
                      'draw_excl': True,
                      'color_dict': None}

    # parse the keyword arguements, asigning defaults if not found.
    for key in DEFAULT_KWARGS:
        if key not in kwargs:
            kwargs[key] = DEFAULT_KWARGS[key]

    wafer = kwargs['wafer']
    die_xy = kwargs['die_xy']
    center_rc = kwargs['center_rc']
    plot_range = kwargs['plot_range']
    draw_wfr = kwargs['draw_wfr']
    draw_excl = kwargs['draw_excl']
    color_dict = kwargs['color_dict']

    dia = wafer[0]
    x_axis_min = -dia * 0.55
    x_axis_max = dia * 0.55
    y_axis_min = -dia * 0.55
    y_axis_max = dia * 0.55

    # Plot Regions Only
    print("Plotting Wafer Map...")
    fig = pyplot.figure()
    fig.clf()
    ax = fig.add_subplot(1, 1, 1, aspect='equal')
    ax.axis([x_axis_min, x_axis_max, y_axis_min, y_axis_max])

    #max_count = float(max([j[2] for j in rcd]))

    for data in rcd:
        if color_dict is None:
            # use black to yellow
            color1 = max(0, min(rescale(data[2], (plot_range), (0, 1)), 1))
            color = (color1, color1, 0)
        else:
            color = color_dict[data[2]]
        # Adjust effective die coords to be relative to the plot origin and
        # also flip the y axis
        x_coord = (data[1] - center_rc[1] - 1.5) * die_xy[0]
        y_coord = -(data[0] - center_rc[0] + 0.5) * die_xy[1]
        rect = mpl.patches.Rectangle((x_coord, y_coord),
                                     die_xy[0],
                                     die_xy[1],
                                     ec=(0, 0, 0),
                                     fc=color,
                                     lw=1)
#        (row, column, data), (plot_min, plot_max), x_size=1, y_size=1)
#        rect = draw_die(
        ax.add_patch(rect)
    if draw_wfr:
        draw_wafer_outline(ax, dia)
    if draw_excl:
        draw_excl_outline(ax, dia, wafer[1], wafer[2])

    fig.show()
    return fig


def plot_wafer_map_xyd(xyd, **kwargs):
    """
    Plots a wafer map via xyd points. All it does is manipulate the data
    from x-y-data into row-column-data and then calls plot_wafer_map.
    """
    plot_wafer_map(convert_rcd_xyd(xyd), **kwargs)


def draw_notch(rad, line_width=2, line_color='r'):
    """ Draws a wafer notch for a given wafer radius"""
    ang = 2.5
    ang_rad = ang * math.pi / 180

    # Define the Notch
    notch_xs = [-rad * math.sin(ang_rad), 0, rad * math.sin(ang_rad)]
    notch_ys = [-rad * math.cos(ang_rad), -rad*0.95, -rad * math.cos(ang_rad)]
    notch = mpl.lines.Line2D(notch_xs, notch_ys,
                             lw=line_width, color=line_color)
    return notch


def draw_wafer_flat(rad, flat_length, line_width=2, line_color='r'):
    """ Draws a wafer flat for a given radius and flat length """
    # Define the flat and center dot
    x = flat_length/2
    y = -math.sqrt(rad**2 - x**2)
    flat = mpl.lines.Line2D([-x, x], [y, y],
                            lw=line_width, color=line_color)
    return flat


def draw_excl_flat(rad, flat_y, line_width=1, line_color='black'):
    """ Draws a wafer flat for a given radius and flat length """
    flat_x = math.sqrt(rad**2 - flat_y**2)
    flat = mpl.lines.Line2D([-flat_x, flat_x],
                            [flat_y, flat_y],
                            lw=line_width, color=line_color)
    return flat


def draw_xy_centerlines(rad, line_width=2, line_color='black'):
    dist = rad * 1.025
    x_cl = mpl.lines.Line2D([-dist, dist], [0, 0],
                            lw=line_width, color=line_color)
    y_cl = mpl.lines.Line2D([0, 0], [-dist, dist],
                            lw=line_width, color=line_color)
    return (x_cl, y_cl)


def draw_wafer_outline(axis, dia):
    """
    Draws a wafer with flat (if defined by the SEMI M1-0302 spec) on an axis.
    """
    rad = float(dia)/2.0
    line_w = 2
    center = mpl.patches.Circle((0, 0), radius=0.005 * dia,
                                ec='red', fc='red')

    # Defined by SEMI M1-0302
    #FLAT_LENGTHS = {50: 15.88, 75: 22.22, 100: 32.5, 125: 42.5, 150: 57.5}

    if dia in FLAT_LENGTHS:
        # A flat is defined, so we draw it.
        flat_size = FLAT_LENGTHS[dia]
        x = flat_size/2
        ang = math.asin(x/rad) * 180 / math.pi

        # Define the wafer arc
        arc = mpl.patches.Arc((0, 0),
                              width=dia, height=dia, angle=-90,
                              theta1=ang, theta2=-ang,
                              lw=line_w, color='r')

        # Add the items to the axis
        axis.add_line(draw_wafer_flat(rad, flat_size, line_w, 'r'))
    else:
        # Flat not defined, so use a notch to denote wafer orientation.
        ang = 2.5

        # Define the wafer arc
        arc = mpl.patches.Arc((0, 0),
                              width=dia, height=dia,
                              angle=-90, theta1=ang, theta2=-ang,
                              lw=line_w, color='r')
        # Add the items to the axis
        axis.add_line(draw_notch(rad, line_w, 'r'))

    axis.add_patch(arc)
    [axis.add_line(cl) for cl in draw_xy_centerlines(rad)]
#    return axis
    axis.add_patch(center)


def draw_excl_outline(axis, dia, excl=5, flatExcl=5):
    """
    Draws a wafer exclusion outline.

    Most of this is copied in draw_wfr_outline, so I probably could merge it
    later...
    """
    rad = float(dia)/2.0
    line_w = 1

    # the Edge exclusion
    exclDia = dia - 2.0 * excl
    exclRad = 0.5 * exclDia

    if dia in FLAT_LENGTHS:
        # This needs to be modified so that it draws the flat exclusion
        # properly if flatExcl < edgeExcl
        # To do so, we need to first find where the normal flat would be
        # Then we move up by flatExcl distance
        # Then find out where that would intersect the exclusion outline

        # A flat is defined, so we find the y-value for it.
        flatSize = FLAT_LENGTHS[dia]

        x = 0.5 * flatSize
        y = -math.sqrt(rad**2 - x**2)

        # Define the arc angle based on the flat exclusion, not the edge
        # exclusion. Find the flat exclusion X and Y coords.
        FSSflatY = y + flatExcl
        FSSflatX = math.sqrt(exclRad**2 - FSSflatY**2)
        ang = math.asin(FSSflatX/exclRad) * 180 / math.pi

        # Define the wafer arc
        arc = mpl.patches.Arc((0, 0),
                              width=exclDia, height=exclDia,
                              angle=-90, theta1=ang, theta2=-ang,
                              lw=line_w, color='black')

        # Add the items to the axis
        axis.add_patch(arc)
        axis.add_line(draw_excl_flat(exclRad, FSSflatY))
    else:
        # Flat not defined, so use a notch to denote wafer orientation.
        ang = 2.5

        # Define the wafer arc
        arc = mpl.patches.Arc((0, 0),
                              width=exclDia, height=exclDia,
                              angle=-90, theta1=ang, theta2=-ang,
                              lw=line_w, color='r')

        # Add the items to the axis
        axis.add_patch(arc)
        axis.add_line(draw_notch(exclRad))


def plot_rcd(rcd, plot_scale='auto', aspect_ratio=1):
    """
    Plots a list of (row, column, data) tuples as a 2D array.
    plot_scale is a tuple of (x, y) values, or 'auto'
    aspect_ratio is a floating point number, defaulting to 1.
    """

    # Convert the RCD data to a numpy 2D array of values
    pyplot.imshow(np.array(rcd_to_2d_array(rcd, 0)))

    # Make sure the aspect ratio is right
    pyplot.axes().set_aspect(aspect_ratio)

    # Change the plot scale and add a color bar
    if plot_scale != 'auto':
        pyplot.clim(plot_scale[0], plot_scale[1])
    pyplot.colorbar()

    pyplot.show()


def main():
    """ Examples of Wafer Map """
    # rcd
    import random
    import numpy as np
    import pyqtgraph as pg

    rcd = []
    for _x in range(20):
        for _y in range(40):
            rcd.append((_x, _y, random.gauss(5, 1)))

#    plot_rcd(rcd)
#    plot_wafer_map(rcd)

    data = np.array(xyd_to_2d_array(rcd, missing=None), dtype=float)
#    print(data)
    pg.image(data)


if __name__ == "__main__":
    print(__doc__)
    main()
