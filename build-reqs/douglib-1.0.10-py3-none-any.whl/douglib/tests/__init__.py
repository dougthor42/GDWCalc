# -*- coding: utf-8 -*-
"""
Created on Wed May 14 15:29:34 2014

@name:          __init__.py
@vers:          0.1
@author:        dthor
@created:       Wed May 14 15:29:34 2014
@modified:      Wed May 14 15:29:34 2014
@descr:         Initialization file for tests for douglib.
"""

VERSION = '0.1.0'
