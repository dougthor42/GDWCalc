
=========
douglib
=========

A collection of functions, classes, utilities, and other items that I've
created over the years.


